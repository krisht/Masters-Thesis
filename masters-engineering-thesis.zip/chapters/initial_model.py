import tensorflow as tf
import tensorflow.contrib.slim as slim
from tensorflow.contrib.layers import xavier_initializer, conv2d, max_pool2d, flatten, fully_connected
import random


def get_model(self, input, reuse=False):
	with slim.arg_scope([slim.layers.conv2d, slim.layers.fully_connected],
						weights_initializer=xavier_initializer(seed=random.random(), uniform=True),
						weights_regularizer=slim.l2_regularizer(0.05), reuse=reuse):
		net = tf.expand_dims(input, axis=3)
		net = conv2d(net, num_outputs=32, kernel_size=4, scope='conv1', trainable=True)
		net = max_pool2d(net, kernel_size=3, scope='maxpool1')
		net = conv2d(net, num_outputs=64, kernel_size=5, scope='conv2', trainable=True)
		net = max_pool2d(net, kernel_size=3, scope='maxpool2')
		net = flatten(net, scope='flatten')
		net = fully_connected(net, 256, scope='fc1', trainable=True)
		net = fully_connected(net, 1024, scope='fc2', trainable=True)
		net = fully_connected(net, self.num_output,
							  activation_fn=None,
							  weights_regularizer=None,
							  scope='output')
		return net