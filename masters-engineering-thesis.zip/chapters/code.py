import os

import matplotlib.pyplot as plt

import tensorflow as tf
import tensorflow.contrib.slim as slim
import random
import numpy as np
from sklearn import neighbors

saver = None
sess = None

loss_mem = []

#Garbage to make it pull properly


bckg_num = 0
artf_num = 1
eybl_num = 2
gped_num = 3
spsw_num = 4
pled_num = 5


def get_loss(loss_mem):
    print(loss_mem)
    plt.figure(1)
    plt.subplot(211)
    plt.plot(loss_mem, 'r--')
    plt.xlabel("100 Iterations")
    plt.ylabel("Average Loss in 100 Iterations")
    plt.title("Iterations vs. Average Loss")
    plt.show()


def save_model(sess, saver):
    save_path = saver.save(sess, "./latest_weights.ckpt")
    print("Model saved in file: %s" % save_path)


class BrainNet:
    def __init__(self, sess, input_shape=[None, 71, 125], num_output=64, num_classes=6, restore_dir=None):

        path = os.path.abspath('/media/krishna/My Passport/DataForUsage/labeled')

        
        self.ARTF = [...]
        self.ARTF_VAL = [...]

        self.BCKG = [...]
        self.BCKG_VAL = [...]

        self.SPSW = [...]
        self.SPSW_VAL = [...]
        self.PLED = [...]
        self.PLED_VAL = [...]
        self.GPED = [...]
        self.GPED_VAL = [...]
        self.EYBL = [...]
        self.EYBL_VAL = [...]

        self.sess = sess
        self.num_classes = num_classes
        self.num_output = num_output
        self.input_shape = input_shape
        self.inference_input = tf.placeholder(tf.float32, shape=input_shape)
        self.inference_model = self.get_model(self.inference_input, reuse=False)
        if restore_dir is not None:
            dir = tf.train.Saver()
            dir.restore(self.sess, restore_dir)

        print(len(self.ARTF))
        print(len(self.BCKG))
        print(len(self.EYBL))
        print(len(self.SPSW))
        print(len(self.PLED))
        print(len(self.GPED))
        self.load_files()

    def triplet_loss(self, alpha):
        self.anchor = tf.placeholder(tf.float32, shape=self.input_shape)
        self.positive = tf.placeholder(tf.float32, shape=self.input_shape)
        self.negative = tf.placeholder(tf.float32, shape=self.input_shape)
        self.anchor_out = self.get_model(self.anchor, reuse=True)
        self.positive_out = self.get_model(self.positive, reuse=True)
        self.negative_out = self.get_model(self.negative, reuse=True)
        with tf.variable_scope('triplet_loss'):
            pos_dist = tf.reduce_sum(tf.square(self.anchor_out - self.positive_out))
            neg_dist = tf.reduce_sum(tf.square(self.anchor_out - self.negative_out))

            basic_loss = tf.maximum(0., alpha + pos_dist - neg_dist)
            loss = tf.reduce_mean(basic_loss)
            return loss

    def load_files(self, validate=False):
        print("Loading New Source Files...")
        if not validate:
            self.bckg = np.load(random.choice(self.BCKG))['arr_0']
            self.eybl = np.load(random.choice(self.EYBL))['arr_0']
            self.artf = np.load(random.choice(self.ARTF))['arr_0']
            self.gped = np.load(random.choice(self.GPED))['arr_0']
            self.pled = np.load(random.choice(self.PLED))['arr_0']
            self.spsw = np.load(random.choice(self.SPSW))['arr_0']
        else:
            self.bckg = np.load(random.choice(self.BCKG_VAL))['arr_0']
            self.eybl = np.load(random.choice(self.EYBL_VAL))['arr_0']
            self.artf = np.load(random.choice(self.ARTF_VAL))['arr_0']
            self.gped = np.load(random.choice(self.GPED_VAL))['arr_0']
            self.pled = np.load(random.choice(self.PLED_VAL))['arr_0']
            self.spsw = np.load(random.choice(self.SPSW_VAL))['arr_0']

    def get_triplets(self):

        choices = ['bckg', 'eybl', 'gped', 'spsw', 'pled', 'artf']
        neg_choices = choices

        choice = random.choice(choices)

        if choice in neg_choices: neg_choices.remove(choice)

        if choice == 'bckg':
            ii = random.randint(0, len(self.bckg) - 1)
            a = self.bckg[ii]

            jj = random.randint(0, len(self.bckg) - 1)
            p = self.bckg[jj]

        elif choice == 'eybl':
            ii = random.randint(0, len(self.eybl) - 1)
            a = self.eybl[ii]

            jj = random.randint(0, len(self.eybl) - 1)
            p = self.eybl[jj]

        elif choice == 'gped':
            ii = random.randint(0, len(self.gped) - 1)
            a = self.gped[ii]

            jj = random.randint(0, len(self.gped) - 1)
            p = self.gped[jj]

        elif choice == 'spsw':
            ii = random.randint(0, len(self.spsw) - 1)
            a = self.spsw[ii]

            jj = random.randint(0, len(self.spsw) - 1)
            p = self.spsw[jj]

        elif choice == 'pled':
            ii = random.randint(0, len(self.pled) - 1)
            a = self.pled[ii]

            jj = random.randint(0, len(self.pled) - 1)
            p = self.pled[jj]

        else:
            ii = random.randint(0, len(self.artf) - 1)
            a = self.artf[ii]

            jj = random.randint(0, len(self.artf) - 1)
            p = self.artf[jj]

        neg_choice = random.choice(neg_choices)

        if neg_choice == 'bckg':
            ii = random.randint(0, len(self.bckg) - 1)
            n = self.bckg[ii]
        elif neg_choice == 'eybl':
            ii = random.randint(0, len(self.eybl) - 1)
            n = self.eybl[ii]
        elif neg_choice == 'gped':
            ii = random.randint(0, len(self.gped) - 1)
            n = self.gped[ii]
        elif neg_choice == 'spsw':
            ii = random.randint(0, len(self.spsw) - 1)
            n = self.spsw[ii]
        elif neg_choice == 'pled':
            ii = random.randint(0, len(self.pled) - 1)
            n = self.pled[ii]
        else:
            ii = random.randint(0, len(self.artf) - 1)
            n = self.artf[ii]

        a = np.expand_dims(a, 0) * 10e4
        p = np.expand_dims(p, 0) * 10e4
        n = np.expand_dims(n, 0) * 10e4

        return np.vstack([a, p, n])

    def get_model(self, input, reuse=False):
        with slim.arg_scope([slim.layers.conv2d, slim.layers.fully_connected],
                            weights_initializer=tf.contrib.layers.xavier_initializer(seed=random.random(),
                                                                                     uniform=True),
                            weights_regularizer=slim.l2_regularizer(0.05), reuse=reuse):
            net = tf.expand_dims(input, axis=3)
            net = slim.layers.conv2d(net, num_outputs=32, kernel_size=4, scope='conv1', trainable=True)
            net = slim.layers.max_pool2d(net, kernel_size=3, scope='maxpool1')
            net = slim.layers.conv2d(net, num_outputs=64, kernel_size=5, scope='conv2', trainable=True)
            net = slim.layers.max_pool2d(net, kernel_size=3, scope='maxpool2')
            net = slim.layers.flatten(net, scope='flatten')
            net = slim.layers.fully_connected(net, 256, scope='fc1', trainable=True)
            net = slim.layers.fully_connected(net, 1024, scope='fc2', trainable=True)
            net = slim.layers.fully_connected(net, self.num_output, activation_fn=None, weights_regularizer=None,
                                              scope='output')
            
            return net

    def train_model(self, learning_rate, keep_prob, batch_size, train_epoch, outdir=None):
        loss = self.triplet_loss(alpha=0.5)
        self.optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)
        self.optim = self.optimizer.minimize(loss=loss)
        self.sess.run(tf.global_variables_initializer())

        count = 0
        ii = 0

        for epoch in range(0, train_epoch):
            ii = 0
            count = 0
            full_loss = 0
            while ii <= batch_size:
                ii += 1
                feeder = self.get_triplets()

                anchor = feeder[0]
                anchor = np.expand_dims(anchor, 0)
                positive = feeder[1]
                positive = np.expand_dims(positive, 0)
                negative = feeder[2]
                negative = np.expand_dims(negative, 0)

                temploss = self.sess.run(loss, feed_dict={self.anchor: anchor, self.positive: positive,
                                                          self.negative: negative})

                if temploss == 0:
                    print(temploss)
                    ii -= 1
                    count += 1
                    continue

                full_loss += temploss

                if ii % 100 == 0:
                    loss_mem.append(full_loss /(100+ count))
                    full_loss = 0

                _, anchor, positive, negative = self.sess.run([self.optim,
                                                               self.anchor_out,
                                                               self.positive_out,
                                                               self.negative_out], feed_dict={self.anchor: anchor,
                                                                                              self.positive: positive,
                                                                                              self.negative: negative})

                d1 = np.linalg.norm(positive - anchor)
                d2 = np.linalg.norm(negative - anchor)

                print("Epoch: ", epoch, "Iteration:", ii, ", Loss: ", temploss, ", Positive Diff: ", d1,
                      ", Negative diff: ", d2)
                print("Iterations skipped: ", count)
            self.validate()
            self.load_files()

    def get_sample(self, size = 1):
        data_list=[]
        class_list=[]

        for ii in range(0, size):
            choice = random.choice(['bckg', 'eybl', 'gped', 'spsw', 'pled', 'artf'])

            if choice == 'bckg':
                ii = random.randint(0, len(self.bckg) - 1)
                data_list.append(self.bckg[ii])
                class_list.append(bckg_num)

            elif choice=='eybl':
                ii = random.randint(0, len(self.eybl) - 1)
                data_list.append(self.eybl[ii])
                class_list.append(eybl_num)
            elif choice =='gped':
                ii = random.randint(0, len(self.gped) - 1)
                data_list.append(self.gped[ii])
                class_list.append(gped_num)
            elif choice == 'spsw':
                ii = random.randint(0, len(self.spsw) -1)
                data_list.append(self.spsw[ii])
                class_list.append(spsw_num)
            elif choice=='pled':
                ii = random.randint(0, len(self.spsw) - 1)
                data_list.append(self.pled[ii])
                class_list.append(pled_num)
            else:
                ii = random.randint(0, len(self.artf) -1)
                data_list.append(self.artf[ii])
                class_list.append(artf_num)


        return data_list, class_list

    def validate(self):
        self.load_files(True)

        for _ in range(0, 5):
            inputs, classes = self.get_sample(size=1000)

            vector_inputs = self.sess.run(self.inference_model, feed_dict={self.inference_input: inputs})

            knn = neighbors.KNeighborsClassifier()
            knn.fit(vector_inputs, classes)

            val_inputs, val_classes = self.get_sample(size=100)

            vector_val_inputs = self.sess.run(self.inference_model, feed_dict={self.inference_input: val_inputs})

            pred_class = knn.predict(vector_val_inputs)

            percentage = len([i for i, j in zip(val_classes, pred_class) if i==j])

            print("Validation Results: %d out of 100 correct" %  percentage )



if __name__ == "__main__":
    try:
        sess = tf.Session()
        model = BrainNet(sess=sess, restore_dir='previous_run/latest_weights.ckpt')
        model.validate()
    except (KeyboardInterrupt, SystemError, SystemExit):
        save_model(sess, saver)
        get_loss(loss_mem)

#
# sess = tf.Session()
# model = BrainNet(sess=sess, restore_dir='./latest_weights.ckpt')